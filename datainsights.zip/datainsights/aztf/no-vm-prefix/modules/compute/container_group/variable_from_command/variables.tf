variable "trigger" {}
variable "variables" {}